import os
import random
import time
from datetime import datetime

# 文件名
filename = "activity.txt"

# 检查文件是否存在，如果不存在则创建并写入初始内容
if not os.path.exists(filename):
    with open(filename, 'w') as file:
        file.write("GitHub Codespaces activity keepalive script\n")

# 主循环，保持脚本持续运行
while True:
    # 生成随机等待时间（2到9分钟）
    wait_time = random.randint(2 * 60, 9 * 60)  # 转换为秒
    print(f"Waiting for {wait_time // 60} minutes and {wait_time % 60} seconds...")

    # 等待随机时间
    time.sleep(wait_time)

    # 获取当前时间戳
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 追加内容到文件
    with open(filename, 'a') as file:
        file.write(f"{timestamp} - Keeping the codespace alive\n")

    # 打印到控制台，表示活动
    print(f"Activity recorded at {timestamp}")